# -*- coding: utf-8 -*-
"""
ACIRM R13 Quick Full-Support Smoke Test (no new data / no scoring)
Purpose: verify the canonical R12 master bundle, nested manifests, core theory values,
N2K_R4 source-proximity conclusion, and N2L_R4 official N1-control conclusion.
Expected upload: ACIRM_R13M_R9C_R12_MASTER_REVIEW_BUNDLE_20260608.zip
This test does NOT re-run NICER/Fermi raw-data analysis and does NOT prove discovery.
"""
import os, json, zipfile, hashlib, csv, io, math, datetime, traceback
from pathlib import Path

EXPECTED_R12 = 'ACIRM_R13M_R9C_R12_MASTER_REVIEW_BUNDLE_20260608.zip'
EXPECTED_R12_SHA256 = 'cff2d1a83bf35b9e365e7676b071680dfa69d4741edcd2a452669b5be350870d'
OUT_ZIP = 'ACIRM_R13M_R9C_R13_QUICK_SUPPORT_TEST_RESULTS.zip'
OUT_SHA = OUT_ZIP + '.sha256.txt'

# Known canonical nested entries in R12
N2K_R4 = 'canonical_inputs/ACIRM_R13M_N2K_R4_VERSION_LABEL_NORMALIZATION_NO_ATTRIBUTION_RESULTS.zip'
N2L_R4 = 'canonical_inputs/ACIRM_R13M_N2L_R4_VERSION_LABEL_NORMALIZATION_OFFICIAL_N1_CONTROL_COMPARISON_NO_SCORE_RESULTS.zip'
R11 = 'canonical_inputs/ACIRM_R13M_R9C_THEORY_R11_FINAL_REVIEW_READY_BRIDGE_PACKAGE.zip'
R7 = 'canonical_inputs/ACIRM_R13M_FINAL_COMPREHENSIVE_AUDIT_R7_CLOSURE_20260608.zip'
EXTERNAL = 'canonical_inputs/ACIRM_R13M_EXTERNAL_AUDIT_STARTER_PACKAGE_20260608.zip'
HANDOFF = 'canonical_inputs/ACIRM_R13M_NEW_CHAT_HANDOFF_MEMORY_20260608_AR.txt'
N1_COORDS = 'canonical_inputs/ACIRM_R13M_N1_OFFICIAL_CONTROL_COORDS_MANIFEST_EXTRACTED.zip'
SYSTEMATICS = 'canonical_inputs/ACIRM_R13_SYSTEMATICS_AUDITED_STRONG_OPERATIONAL_SUPPORT_BRANCH_COMPLETE_HANDOFF_PACKAGE.zip'

REQUIRED_TOP = [
    '00_START_HERE_R12_MASTER_REVIEW_AR.md',
    'R12_MASTER_STATUS.json',
    'R12_THEORY_AND_RESULT_BRIEF_AR.md',
    'R12_CANONICAL_INCLUDED_FILE_SET.csv',
    'R12_EXTERNAL_DEPENDENCIES_NOT_EMBEDDED.csv',
    'MANIFEST_SHA256.json',
    N2K_R4, N2L_R4, R11, R7, EXTERNAL, HANDOFF, N1_COORDS, SYSTEMATICS
]

def sha256_bytes(b: bytes) -> str:
    h=hashlib.sha256(); h.update(b); return h.hexdigest()

def sha256_file(path: str) -> str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def find_r12():
    candidates=[]
    for root in ['/content','/mnt/data','.' ]:
        p=Path(root)/EXPECTED_R12
        if p.exists(): candidates.append(str(p))
    if not candidates:
        # fallback: any matching R12 zip
        for p in Path('.').glob('*R12_MASTER_REVIEW_BUNDLE*.zip'):
            candidates.append(str(p))
        for p in Path('/content').glob('*R12_MASTER_REVIEW_BUNDLE*.zip'):
            candidates.append(str(p))
    return candidates[0] if candidates else None

def read_json_from_zip(z, name):
    return json.loads(z.read(name).decode('utf-8'))

def read_csv_rows_from_zip(z, name):
    return list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8'))))

def verify_manifest_in_zip(z, prefix_label=''):
    result = {'ok': False, 'checked': 0, 'mismatches': [], 'missing': [], 'policy': None}
    if 'MANIFEST_SHA256.json' not in z.namelist():
        result['missing'].append('MANIFEST_SHA256.json')
        return result
    m = read_json_from_zip(z, 'MANIFEST_SHA256.json')
    result['policy'] = m.get('manifest_policy') or m.get('policy')
    files = m.get('files', {})
    ok = True
    for name, expected in files.items():
        if name not in z.namelist():
            ok = False; result['missing'].append(name); continue
        actual = sha256_bytes(z.read(name))
        result['checked'] += 1
        if actual != expected:
            ok = False; result['mismatches'].append({'file': name, 'expected': expected, 'actual': actual})
    result['ok'] = ok and not result['missing'] and not result['mismatches']
    return result

def open_nested_zip(parent_zip, nested_name):
    return zipfile.ZipFile(io.BytesIO(parent_zip.read(nested_name)))

status = {
    'stage': 'ACIRM_R13M_R9C_R13_QUICK_SUPPORT_SMOKE_TEST',
    'created_utc': datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z',
    'purpose': 'Fast no-new-data verification of R12 canonical package consistency and core supportive conclusions.',
    'claim_ceiling': ['NO_NEW_DATA','NO_SCORE','INTERNAL_OPERATIONAL_SUPPORT_ONLY','NOT_EXTERNAL_PROOF','NOT_DISCOVERY','NOT_ATTRIBUTION','NOT_CONFIRMED_MATERIAL_OR_PARTICLE_PRODUCTION'],
    'checks': {},
    'errors': [],
    'final_decision': None
}

try:
    r12_path = find_r12()
    if not r12_path:
        raise FileNotFoundError('Upload ACIRM_R13M_R9C_R12_MASTER_REVIEW_BUNDLE_20260608.zip first.')
    r12_sha = sha256_file(r12_path)
    status['input_file'] = os.path.basename(r12_path)
    status['input_sha256'] = r12_sha
    status['checks']['r12_sha_matches_expected'] = (r12_sha == EXPECTED_R12_SHA256)

    with zipfile.ZipFile(r12_path) as r12:
        names = set(r12.namelist())
        missing_top = [x for x in REQUIRED_TOP if x not in names]
        status['checks']['required_top_level_files_present'] = (len(missing_top)==0)
        status['missing_required_files'] = missing_top
        status['r12_manifest_check'] = verify_manifest_in_zip(r12, 'R12')
        status['checks']['r12_manifest_ok'] = status['r12_manifest_check']['ok']

        # R12 status/readme sanity
        r12_status = read_json_from_zip(r12, 'R12_MASTER_STATUS.json')
        status['r12_master_status'] = r12_status

        # R11 theory bridge
        with open_nested_zip(r12, R11) as r11:
            status['r11_manifest_check'] = verify_manifest_in_zip(r11, 'R11')
            defs = read_json_from_zip(r11, 'ACIRM_R13M_R9C_R11_OPERATIONAL_DEFINITIONS.json')
            locked = defs.get('locked_values', {})
            # dimensional/frequency recomputation
            G = 6.67430e-11
            c = 299792458.0
            M_sun = 1.98847e30
            M_eff = float(locked.get('M_eff_Msun', 5.0)) * M_sun
            k = float(locked.get('k', 2.0))
            chi = float(locked.get('chi_alpha', 1.0))
            f_calc = k * chi * (c**3 * math.log(2.0) / (8.0 * math.pi * G * M_eff))
            f_locked = float(locked.get('f_R9C_Hz'))
            status['theory_values'] = {
                'f_calc_Hz': f_calc,
                'f_locked_Hz': f_locked,
                'f_abs_error_Hz': abs(f_calc-f_locked),
                'N_photons': locked.get('N_photons'),
                'Z1_squared': locked.get('Z1_squared'),
                'rho': locked.get('rho'),
                'p_corr_approx': locked.get('p_corr_approx'),
                'Fermi_broad_lag650_post_pre': locked.get('Fermi_broad_lag650_post_pre'),
                'ring_2_5_delta': locked.get('ring_2_5_delta'),
                'R9C_30_100_GeV_delta': locked.get('R9C_30_100_GeV_delta'),
                'NOGATE_RA240_30_100_GeV_delta': locked.get('NOGATE_RA240_30_100_GeV_delta'),
            }
            status['checks']['theory_frequency_recomputes'] = abs(f_calc-f_locked) < 1e-6
            status['checks']['r11_manifest_ok'] = status['r11_manifest_check']['ok']
            status['checks']['claim_ceiling_present'] = all(x in defs.get('claim_ceiling', []) for x in ['NOT_EXTERNAL_PROOF','NOT_DISCOVERY','NOT_ATTRIBUTION'])

        # N2K_R4 source-proximity canonical check
        with open_nested_zip(r12, N2K_R4) as n2k:
            status['n2k_manifest_check'] = verify_manifest_in_zip(n2k, 'N2K_R4')
            n2k_fd = read_json_from_zip(n2k, 'FINAL_DECISION.json')
            n2k_summary_rows = read_csv_rows_from_zip(n2k, 'ACIRM_R13M_N2K_R1_PRECISE_COORDINATE_ADJUDICATION_SUMMARY.csv')
            nearest = [r['nearest_4fgl_dr4_source'] for r in n2k_summary_rows]
            unique_nearest = len(set(nearest))
            within1 = sum(str(r['within_1p0deg_of_nearest_4fgl']).lower() == 'true' for r in n2k_summary_rows)
            status['n2k_summary'] = {
                'decision': n2k_fd.get('decision'),
                'n_photons': len(n2k_summary_rows),
                'unique_nearest_sources': unique_nearest,
                'max_photons_sharing_one_nearest_source': max(nearest.count(x) for x in set(nearest)) if nearest else 0,
                'within_1deg_nearest_4fgl': within1,
                'nearest_sources': nearest,
            }
            status['checks']['n2k_manifest_ok'] = status['n2k_manifest_check']['ok']
            status['checks']['n2k_not_attribution'] = 'NOT_ATTRIBUTION' in json.dumps(n2k_fd)
            status['checks']['n2k_four_photons_unique_nearest_sources'] = (len(n2k_summary_rows)==4 and unique_nearest==4)

        # N2L_R4 official control comparison check
        with open_nested_zip(r12, N2L_R4) as n2l:
            status['n2l_manifest_check'] = verify_manifest_in_zip(n2l, 'N2L_R4')
            n2l_fd = read_json_from_zip(n2l, 'FINAL_DECISION.json')
            ranking = read_csv_rows_from_zip(n2l, 'ACIRM_R13M_N2L_R2_OFFICIAL_N1_CONTROL_RANKING_DESC.csv')
            by_id = {r['region_id']: r for r in ranking}
            r9c = by_id.get('R9C_CYGX1')
            ra240 = by_id.get('NOGATE_RA240')
            status['n2l_summary'] = {
                'decision': n2l_fd.get('decision'),
                'R9C_delta': int(float(r9c['raw_delta_post_minus_pre'])) if r9c else None,
                'NOGATE_RA240_delta': int(float(ra240['raw_delta_post_minus_pre'])) if ra240 else None,
                'R9C_rank': int(float(r9c['rank_raw_delta_desc'])) if r9c else None,
                'top_region': ranking[0]['region_id'] if ranking else None,
                'top_delta': int(float(ranking[0]['raw_delta_post_minus_pre'])) if ranking else None,
            }
            status['checks']['n2l_manifest_ok'] = status['n2l_manifest_check']['ok']
            status['checks']['n2l_r9c_positive_not_unique'] = (status['n2l_summary']['R9C_delta']==4 and status['n2l_summary']['NOGATE_RA240_delta']==5 and status['n2l_summary']['R9C_rank']==2)
            status['checks']['n2l_no_score_not_attribution'] = ('NO_SCORE' in json.dumps(n2l_fd) and 'NOT_ATTRIBUTION' in json.dumps(n2l_fd))

    required_pass = [
        'r12_sha_matches_expected','required_top_level_files_present','r12_manifest_ok',
        'r11_manifest_ok','theory_frequency_recomputes','claim_ceiling_present',
        'n2k_manifest_ok','n2k_not_attribution','n2k_four_photons_unique_nearest_sources',
        'n2l_manifest_ok','n2l_r9c_positive_not_unique','n2l_no_score_not_attribution'
    ]
    failed = [k for k in required_pass if not status['checks'].get(k, False)]
    status['failed_required_checks'] = failed
    status['final_decision'] = 'PASS_QUICK_INTERNAL_SUPPORT_SMOKE_TEST_NO_NEW_DATA_NO_SCORE' if not failed else 'FAIL_QUICK_SUPPORT_SMOKE_TEST_REVIEW_REQUIRED'
except Exception as e:
    status['final_decision'] = 'ERROR_QUICK_SUPPORT_TEST_DID_NOT_COMPLETE'
    status['errors'].append({'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()})

# Write outputs
outdir = Path('/content' if Path('/content').exists() else '.') / 'acirm_r13_quick_support_output'
outdir.mkdir(parents=True, exist_ok=True)
(outdir/'R13_QUICK_SUPPORT_TEST_RESULT.json').write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding='utf-8')

# Small CSV check table
with open(outdir/'R13_QUICK_SUPPORT_CHECKS.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f)
    w.writerow(['check','pass'])
    for k,v in status.get('checks',{}).items():
        w.writerow([k, bool(v)])

report = f"""# ACIRM R13 Quick Full-Support Smoke Test Result

Final decision: `{status.get('final_decision')}`

This is a no-new-data/no-score verification of package consistency and core supportive conclusions. It does not rerun raw NICER or Fermi/LAT analysis and does not claim proof/discovery/attribution.

## Key checks
- R12 SHA matches expected: {status.get('checks',{}).get('r12_sha_matches_expected')}
- R12 manifest OK: {status.get('checks',{}).get('r12_manifest_ok')}
- R11 theory bridge manifest OK: {status.get('checks',{}).get('r11_manifest_ok')}
- R9C frequency recomputes from formula: {status.get('checks',{}).get('theory_frequency_recomputes')}
- N2K_R4 no-attribution / unique nearest sources: {status.get('checks',{}).get('n2k_four_photons_unique_nearest_sources')}
- N2L_R4 R9C positive but not unique: {status.get('checks',{}).get('n2l_r9c_positive_not_unique')}

## Locked interpretation preserved
R9C remains internally/operationally established inside ACIRM under locked conditions. Fermi/LAT lag650 is a later diagnostic energy response, not the phase inversion itself. The broad response is +21.718969; the 2°-5° ring is +300; the narrow 30-100 GeV tail is R9C +4 but not unique because NOGATE_RA240 is +5.

Ceiling: NO_SCORE / NOT_EXTERNAL_PROOF / NOT_DISCOVERY / NOT_ATTRIBUTION / NOT_CONFIRMED_MATERIAL_OR_PARTICLE_PRODUCTION.
"""
(outdir/'R13_QUICK_SUPPORT_TEST_REPORT.md').write_text(report, encoding='utf-8')

# Package outputs
zip_path = Path('/content' if Path('/content').exists() else '.') / OUT_ZIP
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(outdir.iterdir()):
        z.write(p, p.name)
sha = sha256_file(str(zip_path))
(Path('/content' if Path('/content').exists() else '.') / OUT_SHA).write_text(f'{sha}  {OUT_ZIP}\n', encoding='utf-8')

print('FINAL_DECISION:', status.get('final_decision'))
print('RESULT_ZIP:', zip_path)
print('SHA256:', sha)
print(json.dumps({
    'final_decision': status.get('final_decision'),
    'failed_required_checks': status.get('failed_required_checks'),
    'theory_values': status.get('theory_values'),
    'n2k_summary': status.get('n2k_summary'),
    'n2l_summary': status.get('n2l_summary')
}, indent=2, ensure_ascii=False))
