# ACIRM R13 GitHub Quick Support Workflow

هذا الملف يجعل GitHub Actions يشغل اختبار R13 السريع على حزمة R12 بدون بيانات جديدة وبدون إعادة تحليل NICER/Fermi الخام.

## المطلوب وضعه في جذر المستودع

1. `ACIRM_R13M_R9C_R12_MASTER_REVIEW_BUNDLE_20260608.zip`
2. المجلد `.github/workflows/acirm_r13_quick_support.yml`
3. الملف `tools/COLAB_R13_QUICK_SUPPORT_TEST_ONE_CELL.py`

## طريقة التشغيل

- ارفع الملفات إلى GitHub.
- افتح تبويب **Actions**.
- اختر **ACIRM R13 Quick Support Test**.
- اضغط **Run workflow**.

## النتيجة المتوقعة

إذا كل شيء صحيح، سيظهر القرار:

```text
PASS_QUICK_INTERNAL_SUPPORT_SMOKE_TEST_NO_NEW_DATA_NO_SCORE
```

وسيظهر artifact باسم:

```text
ACIRM_R13_QUICK_SUPPORT_TEST_RESULTS
```

## حدود الاختبار

هذا اختبار دعم داخلي سريع فقط. لا يعيد تشغيل البيانات الخام، ولا يثبت proof/discovery/attribution.
